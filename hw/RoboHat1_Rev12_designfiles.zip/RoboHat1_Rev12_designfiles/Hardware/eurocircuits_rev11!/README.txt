# 20160923 - NA
# Filename: ./GITHUB_VERSION_REV12_designfiles/eurocircuits_rev11!/README.txt

In this directory you'll find the Eurocircuit design files for revision 11.

There's a bug in this revision (fixed in the Rev12 files):
The pull-ups for the analog inputs are connected to the 3v3 power, instead of the 2.048V reference voltage.
To fix this, resistor R30 (47 ohm) is not mounted, and the top side of R12/R13/R14 is connected to the Vref side of C4 (the yellow wire on the bottom side of the hats).
