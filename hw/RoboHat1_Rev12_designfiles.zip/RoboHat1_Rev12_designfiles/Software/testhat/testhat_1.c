// vim: cindent ts=4 nowrap

/* 
   Quick test program for the PCF8591 ADC/DAC, and the MCP23008. Writes a log file, too. 
   Doesn't do any error checking so segfault away!
   Needs the wiringpi libraries.
   (c)20160307 Niels Althuisius, Elektronica Beta VU, Vrije Universiteit Amsterdam, The Netherlands.
   http://wiringpi.com/extensions/i2c-pcf8591
   http://wiringpi.com/examples/quick2wire-and-wiringpi/the-analog-interface-board/
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <wiringPi.h>
#include <pcf8591.h>
#include <mcp23008.h>

/*********************
  variables
  ********************/
const int wpi_PCF8591=64;		// WiringPi's pin number assignments
const int wpi_MCP23008=80;		// 

const int pcf8591_addr=0x48;	// 7-bit I2C address
const int mcp23008_addr=0x27;	// 7-bit I2C address
const float vref=2.048;			// ADC reference voltage

const int LEDR_pin=4;			// Broadcom pin numbers
const int LEDG_pin=14;
const int LEDB_pin=15;

/*********************
  functions
  ********************/
void INThandler(int);
void initGPIO(void);
void initPCF8591(int wpi_nr);
void initMCP23008(int wpi_nr);


/*********************
  main     
  ********************/
int main(int argc, char* argv[])
{
	unsigned long cnt=0;
	time_t timestamp;
	char timestring[20];	// strlen("2009-08-10 18:17:54") + 1
	int pin, val[4];
	float valf[4];
	int mcpval;
	char mcpvals[9];
	int bit;
	int ledval;
	int fd;
	FILE *lognew, *logappend;
	char logfilename[50];
	char logappendname[50]="append-8591.txt";
	char logtxt[80];
	
	signal(SIGINT, INThandler);
	initGPIO();						// Setup GPIO
	initPCF8591(wpi_PCF8591);		// Setup ADC
	initMCP23008(wpi_MCP23008);		// Setup IO-expander

	srand(time(NULL));
	
	// Open two log files: a fresh one with timestamp, and append to default log
	timestamp = time(NULL);
	snprintf(logfilename, 20, "%lu-8591.txt", (unsigned long)timestamp);		// '4294967296' '-8591.txt' = 10 + 9 + null = 20

	strftime(timestring, 20, "%Y-%m-%d %H:%M:%S", localtime(&timestamp));
	printf("# Log start: %lu %s\n"
           "# LogFile  : %s\n"
		   "# LogAppend: %s\n", (unsigned long)timestamp, timestring, logfilename, logappendname);
	
	lognew = fopen(logfilename, "w+");
	logappend = fopen(logappendname, "a+");
		
	for (;;)
	{
		timestamp = time(NULL);

		// sync file buffers every 32 seconds, display legend line
		if (!(cnt % 32))
		{
			printf("# fsync()\n");
			fd = fileno(lognew);
			fsync(fd);
			fd = fileno(logappend);
			fsync(fd);
			printf("Timestamp  - LED0 (V)   - LED1 (V)   - Vaux (V)   - Vbat (V)    -  MCP nc7 nc6 nc5 SrDis GP3 SrvPG PiPG Qi \n");
			//printf("4294967296 - 255 1.000V - 255 1.000V - 255 1.000V - 255 1.000V! -  255   1   1   1     1   1     1    1  1\n"); // test
		}

		// Read ADC values: 0=LDR0, 1=LDR1, 2=Vaux, 3=Vbat
		for (pin=0; pin<4; ++pin)
		{
//			val[pin]=rand() & 0xff;
			val[pin]=analogRead(wpi_PCF8591 + pin);
		}

		// calculate voltages
		valf[0] =   (float)val[0] * vref / 255.0;				// LDR0, max 2.048V
		valf[1] =   (float)val[1] * vref / 255.0;				// LDR1, max 2.048V
		valf[2] =   (float)val[2] * vref / 255.0;				// Vaux, max 2.048V
		valf[3] = ( (float)val[3] * vref / 255.0) * 2.5;		// Vbat, 1:2.5 attenuator, max 5.12V. 

		printf("%10lu - ", (unsigned long)timestamp);
		printf("%3i %1.3fV - ", val[0], valf[0]);
		printf("%3i %1.3fV - ", val[1], valf[1]);
		printf("%3i %1.3fV - ", val[2], valf[2]);
		printf("%3i %1.3fV%c",  val[3], valf[3], (valf[3]<2.8)?'!':' ' );	// with low battery '!'
		printf(" -  ");

		// Toggle servo power enable every second
		if ( cnt & 1)
			digitalWrite(wpi_MCP23008 + 4, 1);
		else
			digitalWrite(wpi_MCP23008 + 4, 0);
		delay(100);

		// Read MCP23008
		// TODO: Can't we read the whole port at once?
		mcpval = 0;
		for (pin=0; pin<8; pin++)
		{
				bit=digitalRead(wpi_MCP23008 + pin);
				mcpvals[pin]=(bit?'1':'0');
				mcpval += bit * 2^pin;
		}

		printf("%3i   ",  mcpval);
		printf("%c   ",   mcpvals[7]);
		printf("%c   ",   mcpvals[6]);
		printf("%c     ", mcpvals[5]);
		printf("%c   ",   mcpvals[4]);
		printf("%c     ", mcpvals[3]);
		printf("%c    ",  mcpvals[2]);
		printf("%c  ",    mcpvals[1]);
		printf("%c",      mcpvals[0]);
		printf("\n");
		fflush(stdout);


		// Put some life in the RGB led
		ledval=rand() % 8;
		digitalWrite(LEDR_pin, ledval & 0x01);
		digitalWrite(LEDG_pin, ledval & 0x02);
		digitalWrite(LEDB_pin, ledval & 0x04);

		if (0)
		{
		if (digitalRead(LEDR_pin)==HIGH)
				digitalWrite(LEDR_pin, LOW);
		else
				digitalWrite(LEDR_pin, HIGH);
		
		if (digitalRead(LEDG_pin)==HIGH)
				digitalWrite(LEDG_pin, LOW);
		else
				digitalWrite(LEDG_pin, HIGH);
		
		if (digitalRead(LEDB_pin)==HIGH)
				digitalWrite(LEDB_pin, LOW);
		else
				digitalWrite(LEDB_pin, HIGH);
		}

		// Write to log files. (what rolls down stairs, alone or in pairs, ...)
		// Format: timestamp,ldr1,ldr1volt,ldr2,ldr2volt,vaux,vauxvolt,vbat,vbatvolt,mcpval,b7,b6,b5,b4,b3,b2,b1,b0
		snprintf(logtxt, sizeof(logtxt)-1, "%lu,%03i,%01.3f,%03i,%01.3f,%03i,%01.3f,%03i,%01.3f,%03i,%c,%c,%c,%c,%c,%c,%c,%c\n", 
						(unsigned long)time(NULL), 
						val[0], valf[0], 
						val[1], valf[1], 
						val[2], valf[2], 
						val[3], valf[3],
						mcpval, mcpvals[7], mcpvals[6], mcpvals[5], mcpvals[4], mcpvals[3], mcpvals[2], mcpvals[1], mcpvals[0] 	);
		fputs( logtxt, lognew );
		fputs( logtxt, logappend );


		delay(1000 - 100);
		cnt++;
	}

	// We'll never get here
	printf("Goodbye world!\n");
	fclose(lognew);
	fclose(logappend);
	return 0;
}


/*********************
  initGPIO()
  ********************/
void initGPIO(void)
{
	wiringPiSetupGpio();

	digitalWrite(LEDR_pin, HIGH);	// high = LED off
	digitalWrite(LEDG_pin, HIGH);
	digitalWrite(LEDB_pin, HIGH);

	pinMode(LEDR_pin, OUTPUT);		// set output mode
	pinMode(LEDG_pin, OUTPUT);
	pinMode(LEDB_pin, OUTPUT);
}


/*********************
  initPCF8591()
  ********************/
void initPCF8591(int wpi_nr)
{
	pcf8591Setup (wpi_nr, pcf8591_addr);	// base address(?), i2c address
}


/*********************
  initMCP23008()
  ********************/
void initMCP23008(int wpi_nr)
{
	mcp23008Setup (wpi_nr, mcp23008_addr);  // base address(?), i2c address
	pinMode(wpi_nr+0, INPUT);               // Qi charge indicator input
	pinMode(wpi_nr+1, INPUT);               // Pi PowerGood
	pinMode(wpi_nr+2, INPUT);               // Servo PowerGood
	pinMode(wpi_nr+3, INPUT);               // GP3 on Qi connector (free to use for input or output)
	pinMode(wpi_nr+4, OUTPUT);              // Servo power disable
	pinMode(wpi_nr+5, INPUT);               // nc (solderpad)
	pinMode(wpi_nr+6, INPUT);               // nc (solderpad)
	pinMode(wpi_nr+7, INPUT);               // nc (solderpad)

// Activate pull-ups on select pins
// This is optional since the board has 1M pullups on all (used) pins
// Choices are PUD_UP, PUD_OFF (and PUD_DOWN?)
	pullUpDnControl ( wpi_nr+0, PUD_UP);    // Qi
	pullUpDnControl ( wpi_nr+1, PUD_UP);    // PiPG 
	pullUpDnControl ( wpi_nr+2, PUD_UP);	// SrvPG
	pullUpDnControl ( wpi_nr+3, PUD_UP);	// GP3
	pullUpDnControl ( wpi_nr+4, PUD_UP);	// Servo power disable, output 
	pullUpDnControl ( wpi_nr+5, PUD_OFF);	// nc
	pullUpDnControl ( wpi_nr+6, PUD_OFF);	// nc
	pullUpDnControl ( wpi_nr+7, PUD_OFF);	// nc
}


void  INThandler(int sig)
{
	signal(sig, SIG_IGN);
	printf("# CTRL-C, quitting!\n");
	exit(0);
}
