#ifndef _BOARD_MODEL_H
#define _BOARD_MODEL_H

void model_board_init(void);
void model_board_redraw(float * acceleration, float * magnetic_field);

#endif
